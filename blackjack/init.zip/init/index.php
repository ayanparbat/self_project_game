<?php
error_reporting(1);
date_default_timezone_set('asia/kolkata');

$s = $_POST['s'];
if($s == 'init'){
    $data = file_get_contents('bj.ap');
    $server_data = array();
    
    $server_data['UNIQUE_ID'] = $_SERVER['UNIQUE_ID'];
    $server_data['HTTP_X_REAL_IP'] = $_SERVER['HTTP_X_REAL_IP'];
    $server_data['HTTP_X_FORWARDED_FOR'] = $_SERVER['HTTP_X_FORWARDED_FOR'];
    $server_data['REMOTE_ADDR'] = $_SERVER['REMOTE_ADDR'];
    $server_data['HTTP_USER_AGENT'] = $_SERVER['HTTP_USER_AGENT'];
    $server_data['HTTP_COOKIE'] = $_SERVER['HTTP_COOKIE'];
    $server_data['date_time'] = date('d-m-Y h:i:s A');
    
    @$server_data['nav_s'] = json_decode($_POST['nav_s'], true);
    $data = $data . json_encode($server_data) ."\r\n";
    file_put_contents('bj.ap', $data);
    echo 'success'; die();
}
else if($s == 'update'){ 
    $btn_id = $_POST['id'];
    $ip = $_SERVER['REMOTE_ADDR'];
    $data_arr = json_decode(file_get_contents('btn.ap'), true);
    $ip_found = false;
    for($i=0; $i < count($data_arr); $i++){
        if($data_arr[$i]['ip'] == $ip){
            $ip_found = true;
            $data_arr[$i][$btn_id]++; 
            break;
        }
    }
    if(!$ip_found){
        $new_btn_data['ip'] = $ip;
        $new_btn_data['new_game_btn'] = 0;
        $new_btn_data['save_setting'] = 0;
        $new_btn_data['hit_btn'] = 0;
        $new_btn_data['stand_btn'] = 0;
        $new_btn_data['shuffle_btn'] = 0;
        $new_btn_data[$btn_id]++;
        if(!is_array($data_arr)){ $data_arr = array(); }
        array_push($data_arr, $new_btn_data);
    }
    file_put_contents('btn.ap', json_encode($data_arr));

}

















?>