<?php

$data = json_decode(file_get_contents('btn.ap'), true);
echo '<pre>'; print_r($data);

echo 'end';

?>