<?php

$file_arr = explode("\n", file_get_contents('bj.ap'));
foreach($file_arr as $data){
    echo "<pre>"; print_r(json_decode($data, true)); echo "</pre>";
}

echo 'end';

?>